from sqlalchemy import Column, Integer, String
from database import Base

# Define To Do class inheriting from Base
#creating employee record with id and name
class ToDo(Base):
    __tablename__ = 'todos'
    id = Column(String, primary_key=True)
    name = Column(String(256))