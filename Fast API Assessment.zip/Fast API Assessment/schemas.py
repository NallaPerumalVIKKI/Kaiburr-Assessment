from pydantic import BaseModel

# Create Employee record (Pydantic Model)
class ToDoCreate(BaseModel):
    id:str
    name:str

# Complete employee record (Pydantic Model)
class ToDoAll(BaseModel):
    id: str
    name: str

    class Config:
        orm_mode = True